For all files in this folder:
	© Copyright, Rabid Viper Productions.

The reason for these files being a normal copyright, is
because they are only used as dummys for the CUBE engine,
could be easily/quickly recreated if needed and have no
real use outside of AssaultCube.
